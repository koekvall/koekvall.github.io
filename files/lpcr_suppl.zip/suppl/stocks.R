# SETTINGS AND DATA -----------------------------------------------------------
data_dir <- "./"
library(RColorBrewer)
library(tidyquant)
library(tidyverse)
library(pls)
library(gt)
set.seed(137)
# logret <- tq_index("DOW") %>%
#  arrange(desc(weight)) %>%
#  tq_get(get = "stock.prices", from = "2010-01-01", to = "2020-03-31") %>%
#  group_by(symbol) %>%
#  tq_transmute(select = "adjusted", mutate_fun = monthlyReturn, type = "log") %>%
#  pivot_wider(names_from = symbol, values_from = monthly.returns) %>%
#  select(-DOW)
# saveRDS(logret, file = paste0(my_dir, "logret.Rds"))

logret <- read_rds(paste0(data_dir, "logret.Rds"))

# FUNCTION TO GET RESULTS -----------------------------------------------------
get_results <- function(resp_symbol = "HD", train_idx = 1:70, scale_X = TRUE)
{
  Y <- as.matrix(logret[, resp_symbol])
  X <- as.matrix(logret[, !names(logret) %in% c("date", resp_symbol)])
  
  # Create training and test data
  # Training response is centered using training data
  # Test response is NOT centered
  Y_train <- scale(Y[train_idx, , drop = F], scale = F)
  mu_Y <- attr(Y_train, "scaled:center") 
  Y_test <- Y[-train_idx, , drop = F]
  
  # Training and test predictors are centered and scaled using training data
  X_train <- scale(X[train_idx, , drop = F], scale = F)
  mu_X <- attr(X_train, "scaled:center")
  s_X <- rep(1, ncol(X_train)) # Scale by 1 if scale_X = FALSE
  
  if(scale_X){
    X_train <- scale(X_train, center = FALSE, scale = TRUE)
    s_X <- attr(X_train, "scaled:scale")
  }
  X_test <- scale(X[-train_idx, , drop = F], center = mu_X, scale = s_X)

  # Fit our model
  fit_aic <- jlpcr::jlpcr(Y = Y_train, X = X_train, k = 1:10)
  fit_bic <- jlpcr::jlpcr(Y = Y_train, X = X_train, k = 1:10, m = log(nrow(X_train)))
  beta_aic <- fit_aic[[paste0("fit_k_", fit_aic$k_star)]]$beta
  beta_bic <- fit_bic[[paste0("fit_k_", fit_bic$k_star)]]$beta
  
  # Fit classical principal components regression and pick k by CV
  fit_pcr <- pls::pcr(Y_train ~ 0 + X_train, validation = "LOO", center = F)
  k_pcr <-  unname(which.min(RMSEP(fit_pcr)$val[1, 1, ]) - 1)
  beta_pcr <- fit_pcr$coefficients[, , k_pcr]
  
  # Fit partial least squares and pick k by CV
  fit_pls <- pls::plsr(Y_train ~ 0 + X_train, method = "simpls", validation = "LOO", center = F)
  k_pls <- unname(which.min(RMSEP(fit_pls)$val[1, 1, ]) - 1)
  beta_pls <- fit_pls$coefficients[, , k_pls]
  
  # Fit Envelope models for all provided ways to select k
  k_env <- Renvlp::u.xenv(Y = Y_train, X = X_train)
  fit_env_aic <- Renvlp::xenv(Y = Y_train, X = X_train, u = k_env$u.aic)
  fit_env_bic <- Renvlp::xenv(Y = Y_train, X = X_train, u = k_env$u.bic)
  fit_env_lrt <- Renvlp::xenv(Y = Y_train, X = X_train, u = k_env$u.lrt)
  beta_env_aic <- fit_env_aic$beta
  beta_env_bic <- fit_env_bic$beta
  beta_env_lrt <- fit_env_lrt$beta
  
  # Fit OLS for comparison
  beta_ols <- coef(lm(Y_train ~ 0 + X_train))
  
  # Store betas
  betas = cbind(beta_aic, beta_bic, beta_pcr, beta_pls, beta_env_aic,
                beta_env_bic, beta_env_lrt, beta_ols)
  
  colnames(betas) <- c("aic", "bic", "pcr", "pls","env_aic", "env_bic",
                        "env_lrt", "ols")

  # Predict
  pred_aic <- X_test %*% beta_aic + mu_Y
  pred_bic <- X_test %*% beta_bic + mu_Y
  
  pred_pcr <- X_test %*% beta_pcr + mu_Y
  
  pred_pls <- X_test %*% beta_pls + mu_Y
  
  pred_env_aic <- X_test %*% beta_env_aic + mu_Y
  pred_env_bic <- X_test %*% beta_env_bic + mu_Y
  pred_env_lrt <- X_test %*% beta_env_lrt + mu_Y
  
  pred_ols <- X_test %*% beta_ols + mu_Y
  
  rmse <- c(
    aic = sqrt(mean((Y_test - pred_aic)^2)),
    bic = sqrt(mean((Y_test - pred_bic)^2)),
    pcr = sqrt(mean((Y_test - pred_pcr)^2)),
    pls = sqrt(mean((Y_test - pred_pls)^2)),
    env_aic = sqrt(mean((Y_test - pred_env_aic)^2)),
    env_bic = sqrt(mean((Y_test - pred_env_bic)^2)),
    env_lrt = sqrt(mean((Y_test - pred_env_lrt)^2)),
    ols = sqrt(mean((Y_test - pred_ols)^2)),
    no_preds = sqrt(mean((Y_test - mu_Y)^2))
  )
  
  selected_k <- c(aic = fit_aic$k_star, bic = fit_bic$k_star,
                  pcr = k_pcr, pls = k_pls, env_aic = k_env$u.aic,
                  env_bic = k_env$u.bic, env_lrt = k_env$u.lrt)
  out <- list(rmse = rmse, selected_k = selected_k, betas = betas,
              mu_Y = mu_Y, Y = Y, X = X, X_s = rbind(X_train, X_test))
  return(out)
}

# TABLE 1 ---------------------------------------------------------------------
tab_full <- matrix(0, 58, 8)
ii <- 1
for(symbol in names(logret)[-1]){
  results <- get_results(resp_symbol = symbol)
  tab_full[ii, ] <- c(results$selected_k, 28)
  tab_full[ii + 1, ] <- results$rmse[1:8] / results$rmse[9]
  ii <- ii + 2
}
colnames(tab_full) <- c("Our (A)", "Our(B)", "PCR", "PLS", "Env (A)", "Env (B)", "Env(L)", "OLS")
tab1 <- round(rbind(
  tab_full[6:5, ],
  apply(tab_full[2 * 1:29, ], 2, mean),
  apply(tab_full[2 * 1:29, ], 2, max),
  apply(tab_full[2 * 1:29 - 1, ], 2, mean)),
  3)
rownames(tab1) <- c("RMSE", "k", "Ave. RMSE", "Max. RMSE", "Ave. k")
gt(tab1) %>%
  tab_header("Prediction Root Mean Squared Errors") %>%
  tab_row_group(group = "All stocks", rows = 3:5) %>%
  tab_row_group(group = "Home Depot", rows = 1:2)

# MODEL FIT FULL DATA ---------------------------------------------------------
y <- as.matrix(logret[, "HD"])
x <- as.matrix(logret[, !names(logret) %in% c("date", "HD")])
fit <- jlpcr::jlpcr(Y =  y, X = x, k = 2, scale = TRUE)
U <- svd(fit$L)$u
summary(lm(y ~ 1 + x %*% U))
fit$tau * (1 + eigen(crossprod(fit$L))$values)

# FIGURE 2 ---------------------------------------------------------------------

cbbPalette <- brewer.pal(n = 5, name = "Dark2")
hd_results <- get_results(resp_symbol = "HD")
par(cex.axis = 1.3, cex.lab = 1.3)
par(mgp=c(2.2,0.45,0), tcl=-0.4, mar=c(3.3,3.6,1.5,1.1))

fit_pred <- hd_results$X_s %*% hd_results$betas + hd_results$mu_Y

plot_mat <- cbind(hd_results$X_s,
                  hd_results$Y / sd(hd_results$Y),
                  fit_pred[, 1] / sd(hd_results$Y))

matplot(plot_mat,
        type = "l",
        col = c(rep("grey", 28), cbbPalette[2], cbbPalette[3]),
        lwd = c(rep(1, 28), 2, 2),
        lty = 1,
        ylab = "Return /  sd(Return)",
        xlab = "Observation",
        ylim = c(-4, 4))
abline(v = 70)

train_mean <- rep(mean(hd_results$Y[0:70] / sd(hd_results$Y)), 71)
test_mean <-  rep(mean(hd_results$Y[71:123] / sd(hd_results$Y)), 55)
lines(x = 0:70, y = train_mean, lty = 2)
lines(x = 70:124, y = test_mean, lty = 2)
